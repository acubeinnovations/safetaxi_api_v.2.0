<?php

//edit_data.php
$id=$_POST['id'];
$status_id=$_POST['name'];
include "db.php";
//

echo $order = "UPDATE notifications 

          SET notification_status_id='$status_id'

          WHERE 

          id='$id'";


//UPDATE  `safetaxi`.`notifications` SET  `notification_status_id` =  '12' WHERE  `notifications`.`id` =1;


mysql_query($order);


?>
