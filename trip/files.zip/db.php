<?php


mysql_connect("localhost","root","anand");

mysql_select_db("safetaxi");

?>
